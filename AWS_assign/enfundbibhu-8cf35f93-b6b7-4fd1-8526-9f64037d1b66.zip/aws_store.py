import json
import boto3
import base64


s3_client = boto3.client('s3')

def lambda_handler(event, context):
    try:
    
        bucket_name = event.get('bucket_name')
        file_name = event.get('file_name')
        file_content = event.get('file_content')  

        
        if not bucket_name or not file_name or not file_content:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "message": "'bucket_name', 'file_name', and 'file_content' are required."
                })
            }

        
        file_data = base64.b64decode(file_content)

        
        s3_client.put_object(Bucket=bucket_name, Key=file_name, Body=file_data)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": f"File '{file_name}' successfully uploaded to bucket '{bucket_name}'."
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "An error occurred.",
                "error": str(e)
            })
        }
